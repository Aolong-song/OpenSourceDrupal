# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 17:06:34 2020

@author: Xiaoli
"""

import jieba

f = open(r"data.txt","r")

text = ""

for line in f:
    text = text+line

seg_list = jieba.cut(text, cut_all=False)
with open("result.txt","w") as f_result:
        f_result.write(" | ".join(seg_list))

